# ⚡ QueueWatch

A small Python CLI that runs jobs in the background, tracks their status in SQLite,
retries temporary failures with backoff, and (optionally) asks an AI to explain
why a job failed.

Whole lines are colour-coded: **green** = success, **yellow** = warning/retrying, **red** = failed.

## Features

- `submit`  – run a job in the background and get a job ID
- `status`  – see one job's details
- `list`    – table of recent jobs
- `stats`   – totals per status (SQL `GROUP BY`)
- `retry`   – run a failed job again
- `explain` – AI explains a failed job (optional; needs an API key)

Statuses: `QUEUED -> RUNNING -> (RETRYING ->) SUCCESS / FAILED`

## Tech stack

Python 3.9+ · Typer (CLI) · Rich (colours/tables) · SQLite (SQL) · Requests (LLM API call) ·
`subprocess` (background workers) · pytest (tests)

## Setup

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"          # installs the `queuewatch` command + pytest
cp .env.example .env             # optional: add LLM_API_KEY to use `explain`
```

## Usage

```bash
queuewatch submit process-csv --file examples/sales.csv
queuewatch submit simulate-failure                       # fails twice, then succeeds (retries!)
queuewatch submit simulate-failure --input always        # retries run out -> FAILED
queuewatch submit simulate-failure --input permanent     # fails once, no retry
queuewatch submit generate-report --input weekly
queuewatch submit simulate-failure --wait                # wait and show the final result

queuewatch list
queuewatch status <job-id>
queuewatch stats
queuewatch retry <job-id>
queuewatch explain <job-id>
```

No install? `python -m queuewatch list` works too.

## How it works

1. `submit` validates the input and saves a `QUEUED` job in SQLite.
2. It starts a separate Python process (`python -m queuewatch.runner <id>`) and returns immediately.
3. That process runs the task and updates the job record: `RUNNING`, `RETRYING`, `SUCCESS` or `FAILED`.
4. Temporary errors are retried up to `MAX_RETRIES` times (default 3), waiting 1s, 2s, 4s...
   Permanent errors (bad input, missing file) are **not** retried.
5. `explain` removes secrets, emails and file paths from the error, then sends one short request to the LLM.

## Project structure

```
queuewatch/
  main.py          CLI commands (Typer)
  ui.py            colours, tables, panels (Rich)
  config.py        settings from environment / .env
  database.py      SQLite connection + table
  jobs.py          create / read / update / count jobs
  tasks.py         the three allowed tasks
  runner.py        background execution + retries
  ai_explainer.py  sanitize + one LLM API call
tests/             pytest tests (LLM is mocked)
examples/sales.csv sample data
```

## Run the tests

```bash
pytest
```

## Design decisions

- **SQLite, not a server database:** zero setup; plenty for a local tool.
- **`subprocess` workers, not Celery/Redis:** same idea (separate worker, tracked status) with far less setup.
  A production version could swap in Celery + Redis.
- **Fixed task list:** no shell commands or user code are ever executed.
- **AI is optional and advisory:** every other command works without a key.

## Limitations

- If a worker process is killed mid-job, that job stays `RUNNING` (no recovery yet).
- No exactly-once guarantee; example tasks are safe to run twice.
- The sanitizer is best-effort, so do not put secrets in job inputs.
- Single machine only.

## Ideas for later

Job timeouts, a `cancel` command, recovering stuck `RUNNING` jobs, JSON output for scripts.
