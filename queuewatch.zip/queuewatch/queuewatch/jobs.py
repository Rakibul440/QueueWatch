"""Job records: create, read, update and count jobs in SQLite."""
import uuid
from datetime import datetime

from queuewatch import database

# The one status model used by the database, the runner and the CLI.
STATUSES = ["QUEUED", "RUNNING", "RETRYING", "SUCCESS", "FAILED"]

_UPDATABLE = {"status", "retries", "result", "error", "started_at", "finished_at"}


def now():
    return datetime.now().isoformat(timespec="seconds")


def create_job(task, input_value=""):
    """Insert a new QUEUED job and return its short ID."""
    job_id = uuid.uuid4().hex[:6]
    database.execute(
        "INSERT INTO jobs (id, task, input, status, created_at) VALUES (?, ?, ?, ?, ?)",
        (job_id, task, input_value, "QUEUED", now()),
    )
    return job_id


def get_job(job_id):
    """Return the job as a dict, or None if the ID does not exist."""
    rows = database.query("SELECT * FROM jobs WHERE id = ?", (job_id,))
    return rows[0] if rows else None


def list_jobs(limit=10):
    """Most recent jobs first."""
    return database.query("SELECT * FROM jobs ORDER BY rowid DESC LIMIT ?", (limit,))


def update_job(job_id, **fields):
    """Update some columns, e.g. update_job(id, status="RUNNING")."""
    unknown = set(fields) - _UPDATABLE
    if unknown:
        raise ValueError(f"Cannot update column(s): {', '.join(sorted(unknown))}")
    assignments = ", ".join(f"{column} = ?" for column in fields)
    database.execute(
        f"UPDATE jobs SET {assignments} WHERE id = ?",
        (*fields.values(), job_id),
    )


def stats():
    """Count jobs per status, e.g. {"QUEUED": 0, "SUCCESS": 4, ...}."""
    rows = database.query("SELECT status, COUNT(*) AS count FROM jobs GROUP BY status")
    counts = {status: 0 for status in STATUSES}
    for row in rows:
        counts[row["status"]] = row["count"]
    return counts
