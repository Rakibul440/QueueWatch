"""Lets you run the tool with:  python -m queuewatch ..."""
from queuewatch.main import app

app()
